**This is the stuff we need to do**
1. Setup app folder DONE
2. Install Kivy DONE
3. Setup validation folder DONE
4. Create custom layer module DONE
5. Bring over h5 model DONE
   
6. Import dependencies for Kivy DONE
7. Build layout DONE
8. Build update function and render webcam DONE
9. Bring over preprocessing function DONE 

10. Bring over verification function DONE
11. Update verification function to handle new paths and save current frame DONE
12. Update verification function to set verified text DONE
13. Link verficiation function to button DONE
14. Setup Logger DONE